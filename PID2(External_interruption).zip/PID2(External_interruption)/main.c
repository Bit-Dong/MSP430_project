#include <msp430.h> 
#include "driverlib.h"
#include <HARDWARE/oled.h>
#include <HARDWARE/led.h>
#include <HARDWARE/motor.h>
#include <HARDWARE/timer.h>
#include <HARDWARE/pwm.h>
#include <HARDWARE/pid.h>
#include <HARDWARE/exit.h>
#include "msp430f5529.h"

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����
/**
  *                      MSP430F5529

        Motor��          P3.5��P3.6(��)        P3.0��P3.1(��)
        PWM��            P2.4(��)              P2.5(��)
        A/B�ࣺ          P12��P13(��)          P14��P15(��)
        OLED��           P2.0(SCL)             P2.2(SDA)

 */



 int count0=0,n=0,count1=0;
 int pwm_out0,pwm_out1;
 PID pid0,pid1;
int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	LED_Init();
	OLED_Init();
	motor_gpio_init();
	OLED_Refresh();
	init_encoders();
	TIMER_B0_Init(25);
//    PID_Init(&pid0,50,2,0);      // Ŀ�����壺 0~70
    PID_Init(&pid1,20,2,0);      // Ŀ�����壺 0~70
	while(1)
	{

	}

}


#pragma vector=TIMER0_B0_VECTOR
__interrupt void Timer_B0 (void)
{
    _DINT();  //�����ж�
    n++;

//    pwm_out0=Position_PID_Cal(&pid0,count0,35);
    pwm_out1=Position_PID_Cal(&pid1,count1,45);
//    SetPwm_Init(24,1000,pwm_out0);
    SetPwm_Init(25,1000,pwm_out1);
    if(n%40==0)
    {
        n=0;
        OLED_ShowNum(55,10,(u32)count0,4,16,1);
        OLED_ShowNum(55,30,(u32)count1,4,16,1);
        OLED_Refresh();
    }

 //   count0=0;
    count1=0;

    TB0CTL &= ~TAIFG;
    _EINT();  //�����ж�
}

#pragma vector = PORT1_VECTOR
__interrupt void P1_ISR(void)
{
    _DINT();

    switch(P1IV)

    {
        case P1IV_P1IFG2:
            count0++;
            break;

        case P1IV_P1IFG3:
            count0++;
            break;

//        case P1IV_P1IFG4:
//            count1++;
//            break;
//
//        case P1IV_P1IFG5:
//            count1++;
//            break;

        default:
            break;

    }
    _EINT();
}

#pragma vector = PORT2_VECTOR
__interrupt void P2_ISR(void)
{
    _DINT();

    switch(P2IV)

    {
        case P2IV_P2IFG3:
            count1++;
            break;

        case P2IV_P2IFG6:
            count1++;
            break;

        default:
            break;

    }
    _EINT();
}


