#include "HC_SR04.h"
#include "msp430f5529.h"

float   distance;

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����

void Clock_init()
{
  UCSCTL3 = SELREF_2;                       // Set DCO FLL reference = REFO
  UCSCTL4 |= SELA_2;                        // Set ACLK = REFO
  UCSCTL0 = 0x0000;                         // Set lowest possible DCOx, MODx

  // Loop until XT1,XT2 & DCO stabilizes - In this case only DCO has to stabilize
  do
  {
    UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                            // Clear XT2,XT1,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag

  __bis_SR_register(SCG0);                  // Disable the FLL control loop
  UCSCTL1 = DCORSEL_5;                      // Select DCO range 16MHz operation
  UCSCTL2 |= 30;                           // Set DCO Multiplier for 8MHz
                                            // (N + 1) * FLLRef = Fdco
                                            // (31 + 1) * 32768 = 1MHz
  __bic_SR_register(SCG0);                  // Enable the FLL control loop

  // Worst-case settling time for the DCO when the DCO range bits have been
  // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 5xx
  // UG for optimization.
  // 32 x 32 x 8 MHz / 32,768 Hz = 250000 = MCLK cycles for DCO to settle
  __delay_cycles(250000);
}

void sr04_init()
{
  USONUD_OUT |= TRIG;
  USOUND_DIR |= TRIG;
  USOUND_SEL |= ECHO ; //CCI0A
}


float GetDistance()
{
    unsigned int capV = 0;
    TA0CTL |= MC_2 + TASSEL_2 + TACLR; //���� SMCLK �����
    TA0CCTL1 |= CM_1 + CAP + SCS + CCIE + CCIS_0;//�����ز���  ����ģʽ  ͬ��ģʽ  ʹ���ж� CCI0A
    USONUD_OUT |= TRIG;
    __delay_cycles(200);
   // delay_us(15);
    USONUD_OUT &= ~TRIG;
    while((TA0CCTL1 & CCIFG) ==0); //�ȴ�������
    TA0CTL &= ~MC_3; //���MC_����λ,���� CM_1 | CM_2 = CM_3
    TA0CTL |= MC_2 + TACLR; //�������� ���TA�ļ���ֵ
    TA0CCTL1 &= ~CCIFG; //���жϱ�־
    TA0CCTL1 |= CM_2; //�½��ز�׽
    while((TA0CCTL1 & CCIFG) ==0); //�ȴ��½���
    capV = TA0CCR1;  //�õ���������ֵ
    distance = 1.619e-2 * capV ;//�������
    TA0CCTL1 &= ~CCIFG; //���жϱ�־
    return distance;
}




