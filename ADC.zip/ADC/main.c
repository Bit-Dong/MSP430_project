#include <msp430.h> 
#include <HARDWARE/oled.h>
#include <HARDWARE/adc.h>
#include <HARDWARE/led.h>
#include "msp430f5529.h"

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����
/**
 *                  MSP430F5529
        OLED��       P2.0(SCL)             P2.2(SDA)
        ADC:
                    Vin0  -->|   P6.0/CB0/A0
                    Vin1  -->|   P6.1/CB1/A1
                    Vin2  -->|   P6.2/CB2/A2
                    Vin3  -->|   P6.3/CB3/A3
 */

int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

	ADC_Init();
	LED_Init();
	OLED_Init();

	while(1)
	{

	    OLED_Refresh();
        OLED_ShowString(20,0,"ADC0=",16,1);
        OLED_ShowNum(60,0,ADC12MEM0,4,16,1);

        OLED_ShowString(20,17,"ADC1=",16,1);
        OLED_ShowNum(60,17,ADC12MEM1,4,16,1);

        OLED_ShowString(20,34,"ADC2=",16,1);
        OLED_ShowNum(60,34,ADC12MEM2,4,16,1);

        OLED_ShowString(20,50,"ADC3=",16,1);
        OLED_ShowNum(60,50,ADC12MEM3,4,16,1);
        OLED_Refresh();

	}

}
