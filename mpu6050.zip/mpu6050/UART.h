/*
 * UART.h
 *
 *  Created on: 2021��9��5��
 *      Author: dwb
 */

#ifndef UART_H_
#define UART_H_
void UARTInit();
void FS(unsigned char*write);
void FSNO(unsigned char*write);
void HS(int a);


#endif /* UART_H_ */
