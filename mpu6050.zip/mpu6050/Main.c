#include "driverlib.h"
#include "mpu6050/Mpu-6050.h"
#include "UART.h"
#include "clk.h"
int main(void)
{
    float a;
    float b;
    float c;
    unsigned char f[3]="��";
    unsigned char x[15]="X��Ƕ�---  ";
    unsigned char y[15]="Y��Ƕ�---  ";
    unsigned char z[15]="Z��Ƕ�---  ";
    unsigned char h[30]="--------------------";


  WDT_A_hold(WDT_A_BASE);
  InitMPU6050();
  UARTInit();
  clk_Init ();

  while(1)
  {

      a=Mpu6050AccelAngle(ACCEL_XOUT);
      b=Mpu6050AccelAngle(ACCEL_YOUT);
      c=Mpu6050AccelAngle(ACCEL_ZOUT);
      __delay_cycles(8000000);
      FS(h);
      FSNO(x);
      HS(a);
      FS(f);
      FSNO(y);
      HS(b);
      FS(f);
      FSNO(z);
      HS(c);
      FS(f);


  }


}
