/*
 * �Ա����̣�Dc�󳿿Ƽ�
 * https://shop143485251.taobao.com/shop/view_shop.htm?tracelog=twddp&user_number_id=1674802168
 *
 * ��Ȩ���������ļ���Ȩ���������У�����ѧϰ���Ͻ����ã�
 * ��    �ߣ��Գ�
 * QQ����Ⱥ��176242843
 * �ļ�����user_config.h
 * ��    ����V1.0
 * ʱ    �䣺2019.06.16
 * ��    �ܣ� �����ļ�
 * ˵    ����
 *          �ڸ��ļ��д��һЩ���������ó���
 */
#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#include "MSP430F5xx_6xx/driverlib.h"
#include <User_Uart.h>
#include <stdint.h>
//#include <HC_SR.h>

/********************************************************************
************************** ��Ҫʹ��ʱ��****************************
********************************************************************/

#define MCLK_Fre 4000000           // ϵͳʱ��Ƶ��
#define CPU_F ((double)MCLK_Fre)   // MCLK = MCLK_Fre
//#define CPU_F ((double)32768)   // �ⲿ��Ƶ����32.768KHZ
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))


extern void GPIO_Init(void);
extern void SetVcoreUp (unsigned int level);
//extern void UCS_Init(void);                   // ����ʱ��Ƶ�ʣ�

void GPIO_Init(void)    // f5529 gpio config
{
    P1OUT = 0X00;   P2OUT = 0X00;   P3OUT = 0X00;   P4OUT = 0X00;
    P5OUT = 0X00;   P6OUT = 0X00;   P7OUT = 0X00;   P8OUT = 0X00;

    P1DIR = 0X00;   P2DIR = 0X00;   P3DIR = 0X00;   P4DIR = 0X00;
    P5DIR = 0X00;   P6DIR = 0X00;   P7DIR = 0X00;   P8DIR = 0X00;
}


//void UCS_Init(void)
//{
////    P1DIR |= BIT0;                            // ACLK set out to pins
////    P1SEL |= BIT0;
//    P2DIR |= BIT2;                            // SMCLK set out to pins
//    P2SEL |= BIT2;
////    P7DIR |= BIT7;                            // MCLK set out to pins
////    P7SEL |= BIT7;
//
//    P5SEL |= (BIT2 + BIT3 + BIT4+BIT5);                       // Select XT1  XT2
//
//    // Increase Vcore setting to level3 to support fsystem=25MHz
//    // NOTE: Change core voltage one level at a time..
//    SetVcoreUp (0x01);
//    SetVcoreUp (0x02);
//    SetVcoreUp (0x03);
//
////    UCSCTL6 &= ~XT1OFF;              // XT1 On
////    UCSCTL6 |= XT2OFF;
//    UCSCTL6 |= XCAP_3;                        // Internal load cap
//
//    UCSCTL3 = SELREF__XT2CLK;                 // Set DCO FLL reference = XT2
//    UCSCTL4 |= (SELA__XT1CLK + SELS__XT2CLK   + SELM__DCOCLKDIV );
//                                              // ACLK = 32.7678  SMCLK = XT2 = 4.0076MHz
//                                              // MCLK = 24.00456MHz
//
//    __bis_SR_register(SCG0);                  // Disable the FLL control loop
//    UCSCTL0 = 0x0000;                         // Set lowest possible DCOx, MODx
//    UCSCTL1 = DCORSEL_7;                      // Select DCO range 50MHz operation
//    UCSCTL2 = FLLD_0 + 5;                     // Set DCO Multiplier for 25MHz
//                                              // (N + 1) * FLLRef = Fdco
//                                              // (5 + 1) * 4,000,000HZ = 25MHz
//                                              // Set FLL Div = fDCOCLK/2
//    __bic_SR_register(SCG0);                  // Enable the FLL control loop
//
//    __delay_cycles(100000);
//
//    // Loop until XT1,XT2 & DCO stabilizes - In this case only DCO has to stabilize
//    do
//    {
//      UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
//                                              // Clear XT2,XT1,DCO fault flags
//      SFRIFG1 &= ~OFIFG;                      // Clear fault flags
//    }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag
//
//
//    UCSCTL6 &= ~(XT1DRIVE_3);                 // Xtal is now stable, reduce drive strength
//    UCSCTL6 &= ~XT2DRIVE0;                    // Decrease XT2 Drive according to
////    UCSCTL5  = DIVS__4;
//}

void SetVcoreUp (unsigned int level)
{
  // Open PMM registers for write
  PMMCTL0_H = PMMPW_H;
  // Set SVS/SVM high side new level
  SVSMHCTL = SVSHE + SVSHRVL0 * level + SVMHE + SVSMHRRL0 * level;
  // Set SVM low side to new level
  SVSMLCTL = SVSLE + SVMLE + SVSMLRRL0 * level;
  // Wait till SVM is settled
  while ((PMMIFG & SVSMLDLYIFG) == 0);
  // Clear already set flags
  PMMIFG &= ~(SVMLVLRIFG + SVMLIFG);
  // Set VCore to new level
  PMMCTL0_L = PMMCOREV0 * level;
  // Wait till new level reached
  if ((PMMIFG & SVMLIFG))
    while ((PMMIFG & SVMLVLRIFG) == 0);
  // Set SVS/SVM low side to new level
  SVSMLCTL = SVSLE + SVSLRVL0 * level + SVMLE + SVSMLRRL0 * level;
  // Lock PMM registers for write access
  PMMCTL0_H = 0x00;
}

#endif
