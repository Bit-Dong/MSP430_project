#ifndef HARDWARE_BEEP_H_
#define HARDWARE_BEEP_H_

#include "msp430f5529.h"
void beep_init();

void Beep();

#endif /* HARDWARE_BEEP_H_ */
