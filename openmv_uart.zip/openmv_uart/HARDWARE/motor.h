/*
 * motor.h
 *
 *  Created on: 2023��3��30��
 *      Author: 29054
 */

#ifndef HARDWARE_MOTOR_H_
#define HARDWARE_MOTOR_H_


void motor_gpio_init(void);
void head(void);
void back(void);
void left(void);
void right(void);
void stop(void);

#endif /* HARDWARE_MOTOR_H_ */
