#include <msp430.h> 
#include <HARDWARE/oled.h>
#include <HARDWARE/hongwai.h>
#include <HARDWARE/led.h>
#include <HARDWARE/motor.h>
#include <HARDWARE/pwm.h>
#include <HARDWARE/HC_SR04.h>
#include <HARDWARE/bluetooth.h>
#include <HARDWARE/anjian.h>
#include <HARDWARE/beep.h>
#include "msp430f5529.h"

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����
/**
  *                  MSP430F5529

        Motor��      P3.5��P3.6(��)        P3.0��P3.1(��)
        PWM��        P2.4(��)              P2.5(��)
        TCRT5000L��  P3.4(��)   P6.6(��)   P1.6(��)
        OLED��       P2.0(SCL)             P2.2(SDA)
        HC_SR-04��   P1.2(echo)            P1.4(Trig)
        ATK_HC-05:   P4.4(TX)              P4.5(RX)
        Beep:        P8.2(��)              P8.1(��)
        Key:         P1.1(����ģʽ)        P2.1(����ģʽ)   [Ĭ��ѭ��ģʽ]
 */


int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

	float distance;
	int flag=0;

	LED_Init();
	OLED_Init();
	motor_gpio_init();
	HONGWAI_Init();
	sr04_init();
	OLED_ShowString(35,0," Nie Dong",16,1);
    OLED_ShowString(35,20,"Tracking",16,1);
	OLED_Refresh();
	Anjian_Init();
	beep_init();
	while(1)
	{
	    SetPwm_Init(25,2000,2000);//�ұ�
	}

////
//	    if((P1IN & BIT1)==0){
//	        delay_us(10);
//	        OLED_ShowString(35,20,"        ",16,1);
//            OLED_ShowString(30,30,"BuleTooth",16,1);
//            OLED_Refresh();
//            blue_init();
//	    }
////
//	    if((P2IN & BIT1)==0){
//	        delay_us(10);
//	        OLED_ShowString(35,20,"        ",16,1);
//	        OLED_ShowString(40,25,"  Safe",16,1);
//	        while(1){
//	            distance=GetDistance();
//	            if((P1IN&BIT1)==0) {
//	                delay_us(100);
//	                OLED_ShowString(28,50,"          ",16,1);
//	                OLED_ShowString(40,25,"      ",16,1);
//	                OLED_ShowString(30,30,"BuleTooth",16,1);
//	                OLED_Refresh();
//	                blue_init();
//	                break;
//	            }
//	            if(distance>=40){
//	                if(flag==0){
//	                       OLED_ShowString(40,25,"  ",16,1);
//	                       OLED_ShowString(28,50,"            ",16,1);
//	                       OLED_Refresh();
//	                       flag=1;
//	                }
//	                SetPwm_Init(24,2000,400);//���
//	                SetPwm_Init(25,2000,400);//�ұ�
//                    head();
//	               }
//	               else{
//	                   if(flag==1){
//	                       OLED_ShowString(40,25,"Un",16,1);
//	                       OLED_ShowString(28,50,"Data:   cm",16,1);
//	                       OLED_ShowNum(68,50,(u32)distance,3,16,1);
//	                       OLED_Refresh();
//	                       flag=0;
//	                   }
//	                   Beep();
//	                   head();
//	                   SetPwm_Init(24,2000,150);//���
//	                   SetPwm_Init(25,2000,450);//�ұ�
//	               }
//	        }
//	    }
//
//
//	    if(((P3IN&BIT4)==BIT4) && ((P1IN&BIT6)==BIT6))       //û�ȵ���ֱ��
//	    {
//	        head();
//	        SetPwm_Init(24,2000,400);//���
//	        SetPwm_Init(25,2000,400);//�ұ�
//	    }
//	    else if(((P3IN&BIT4)!=BIT4) && ((P1IN&BIT6)==BIT6)) //��߲ȵ�����ת
//	    {
//	        left();
//	        SetPwm_Init(24,2000,200);//���
//	        SetPwm_Init(25,2000,400);//�ұ�
//	    }
//	    else if(((P3IN&BIT4)==BIT4) && ((P1IN&BIT6)!=BIT6)) //�ұ߲ȵ�����ת
//	   {
//	        right();
//	        SetPwm_Init(24,2000,400);//���
//	        SetPwm_Init(25,2000,200);//�ұ�
//	   }
//	    else if(((P3IN&BIT4)!=BIT4) && ((P6IN&BIT6)!=BIT6) && ((P1IN&BIT6)!=BIT6))  //ȫ�ȵ�
//	   {
//	        head();
//            SetPwm_Init(24,2000,400);//���
//            SetPwm_Init(25,2000,400);//�ұ�
//	   }
//
//	}

}


// Echo back RXed character, confirm TX buffer is ready first����������֮ǰȷ�����ͻ���׼����
#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)
{
  switch(__even_in_range(UCA1IV,4))
  {

  case 0:     //���ж�
      break;                             // Vector 0 - no interrupt
  case 2:                                   // Vector 2 - RXIFG  �����ж�

   while (!(UCA1IFG&UCTXIFG));    // USCI_A1 TX buffer ready?   UCTXIFG(USCI Transmit Interrupt Flag)
                                   //�ȴ����ݷ������ ���UCTXIFG��1 ����ѭ��
//    UCA1TXBUF = UCA1RXBUF;                  // TX -> RXed character

   if(UCA1RXBUF=='0'){
         stop();
   }
   if(UCA1RXBUF=='2'){   //ǰ��
       head();
       SetPwm_Init(24,2000,250);//���
       SetPwm_Init(25,2000,380);//�ұ�
   }
   if(UCA1RXBUF=='4'){  //��ת
       P3OUT |= BIT5;P3OUT &=~ BIT6;  //������ת
       P3OUT &=~ BIT1;P3OUT |= BIT0;  //������ת
       SetPwm_Init(24,2000,200);//���
       SetPwm_Init(25,2000,400);//�ұ�
   }
   if(UCA1RXBUF=='6'){  //��ת
       P3OUT |= BIT5;P3OUT &=~ BIT6;  //������ת
       P3OUT &=~ BIT1;P3OUT |= BIT0;  //������ת
       SetPwm_Init(24,2000,300);//���
       SetPwm_Init(25,2000,200);//�ұ�
   }
   if(UCA1RXBUF=='8'){  //����
       back();
       SetPwm_Init(24,2000,250);//���
       SetPwm_Init(25,2000,380);//�ұ�
   }
   if(UCA1RXBUF=='5'){  //ԭ�ش�ת
      left();
      SetPwm_Init(24,2000,375);//���
      SetPwm_Init(25,2000,150);//�ұ�
   }

   break;
  case 4:
      break;                             // Vector 4 - TXIFG  �����ж�


  default: break;
  }
}
// UCTXIFG=0x02��UCA1IFG&UCTXIFG����UCA1IFG��UCTXIFGλΪ1ʱ��˵��UCA1TXBUFΪ�գ�
//����whileѭ��ѭ������UCTXIFGλΪ0ʱUCA1TXBUF��Ϊ�գ�ͣ��ѭ����


