#include <msp430.h> 
#include "msp430f5529.h"
#include "driverlib.h"
#include <HARDWARE/oled.h>
#include <HARDWARE/led.h>
#include <HARDWARE/motor.h>
#include <HARDWARE/timer.h>
#include <HARDWARE/pwm.h>
#include <HARDWARE/pid.h>
#include <HARDWARE/adc.h>
#include <HARDWARE/exit.h>
#include <HARDWARE/mpu6050.h>
#include <HARDWARE/bluetooth.h>
#include <HARDWARE/openmv.h>
#include <HARDWARE/huidu.h>
#include <HARDWARE/beep.h>
#include <HARDWARE/delay.h>
#include <HARDWARE/anjian.h>
#include <HARDWARE/hongwai.h>
#include <HARDWARE/judge.h>
#include<stdio.h>
#include<math.h>

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����
/**c
  *                      MSP430F5529
  *     Motor��          P3.5��P3.6(��)        P3.0��P3.1(��)
        PWM��            P2.4(��)              P2.5(��)
        A/B�ࣺ          P12��P13(��)          P13��P14(��)
        OLED��           P2.0(SCL)            P2.2(SDA)
        ��·�Ҷȣ�       P6.5(��)    P6.0    P6.1    P6.2(��)    P6.3    P6.4    P7.0(��)
        MPU6050:         P8.1(SCL)            P8.2(SDA)      GND(ADC)
        BlueTooth:       P4.4(TX)             P4.5(RX)
        openmv:          P3.3(TX)             P3.4(RX)
 */

int find_num=0,oled_flag=1,head_flag=1;

int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	LED_Init();
	motor_gpio_init();
	Anjian_Init();
	beep_init();
	OLED_Init();
    OLED_ShowString(10,24,"N U M: ",16,1);
	OLED_Refresh();
//	TIMER_B0_Init(6000);
	HONGWAI_Init();
	HuiDu_Init();
	//
	openmv_init();
	blue_init();
	stop();

	//InitMPU6050();
	//ADC_Init();
	//init_encoders();
	//PID_Init(&pid0,10,2,1);      // Ŀ�����壺 0~80
	//PID_Init(&pid1,10,2,1);
	while(1)
	{
	    //UCA1TXBUF='7';

	    while(!find_num)
        {
	        P1OUT|=BIT0;
        }
	    P1OUT&=~BIT0;

        if(oled_flag==1)
        {
            oled_flag=0;
            OLED_ShowNum(65,24,find_num,1,16,1);
            OLED_Refresh();
        }
        while((P7IN&BIT4)==BIT4)
        {
            P4OUT|=BIT7;
        }
        P4OUT&=~BIT7;

        while(head_flag)
        {
            head_flag=0;
            head();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(500000);
        }
        break;
	}

	while(1)
	{
        if(find_num==1)
        {
            judge1();
        }
        if(find_num==2)
        {
            judge2();
        }
        if(find_num==3)
        {
            judge3();
        }
        if(find_num==4)
        {
            judge4();
        }
        if(find_num==5)
        {
            judge5();
        }
        if(find_num==6)
        {
            judge6();
        }
        if(find_num==7)
        {
            judge7();
        }
        if(find_num==8)
        {
            judge8();
        }
	}
}


//
//#pragma vector=TIMER0_B0_VECTOR
//__interrupt void Timer_B0 (void)
//{
//    _DINT();  //�����ж�
//    TimeB0_num++;
//    P1OUT|=BIT0;
//    if(TimeB0_num==2) P1OUT&=~BIT0;
////    pill=0;
//    flag5555=-9;
//    flag55=0;
//
//    TB0CTL &= ~TAIFG;   //�����־λ
//    _EINT();  //�����ж�
//}

/* --------------   �����ж�(OpenMVͨ��)    ----------------*/
// Echo back RXed character, confirm TX buffer is ready first����������֮ǰȷ�����ͻ���׼����
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{

  switch(__even_in_range(UCA0IV,4))
  {

  case 0:     //���ж�
      break;                             // Vector 0 - no interrupt
  case 2:                                   // Vector 2 - RXIFG  �����ж�

   while (!(UCA0IFG&UCTXIFG));    // USCI_A1 TX buffer ready?   UCTXIFG(USCI Transmit Interrupt Flag)
                                   //�ȴ����ݷ������ ���UCTXIFG��1 ����ѭ��
//    UCA0TXBUF = UCA0RXBUF;                  // TX -> RXed character

   if(UCA0RXBUF=='2'){
       find_num=2;
       UCA1TXBUF='2';
   }
   if(UCA0RXBUF=='4'){
       find_num=4;
       UCA1TXBUF='4';
   }
   if(UCA0RXBUF=='6'){
       find_num=6;
       UCA1TXBUF='6';
   }
   if(UCA0RXBUF=='8'){
       find_num=8;
       UCA1TXBUF='8';
   }
   if(UCA0RXBUF=='5'){
       find_num=5;
       UCA1TXBUF='5';
   }
   if(UCA0RXBUF=='1'){
       find_num=1;
       UCA1TXBUF='1';
   }
   if(UCA0RXBUF=='3'){
       find_num=3;
       UCA1TXBUF='3';
   }
   if(UCA0RXBUF=='7'){
       find_num=7;
       UCA1TXBUF='7';
   }

   UCA0IE &= ~(UCRXIE); // ���ý��պͷ����ж�
   break;
  case 4:
      break;                             // Vector 4 - TXIFG  �����ж�


  default: break;
  }
}







