#include "driverlib.h"
#include "mpu_mytype.h"
#include "mpu6050.h"
#include "mpu_iic.h"
#include "oled.h"

 /* MPU6050 */
 float a;
 float b;
 float c;


void ByteWrite6050(unsigned char REG_Address,unsigned char REG_data);
unsigned char ByteRead6050(unsigned char REG_Address);
int Get6050Data(unsigned char REG_Address);
void InitMPU6050();
float Mpu6050AccelAngle(signed char dir);
float Mpu6050GyroAngle(signed char dir);

//**************************************
//鍚慖2C璁惧鍐欏叆涓�涓瓧鑺傛暟鎹�
//**************************************
void ByteWrite6050(unsigned char REG_Address,unsigned char REG_data)
{
    IIC_start();                  //璧峰淇″彿
    IIC_writebyte(SlaveAddress);   //鍙戦�佽澶囧湴鍧�+鍐欎俊鍙�
    IIC_writebyte(REG_Address);    //鍐呴儴瀵勫瓨鍣ㄥ湴鍧�锛�
    IIC_writebyte(REG_data);        //鍐呴儴瀵勫瓨鍣ㄦ暟鎹紝
    IIC_stop();                   //鍙戦�佸仠姝俊鍙�
}
//**************************************
//浠嶪2C璁惧璇诲彇涓�涓瓧鑺傛暟鎹�
//**************************************
unsigned char ByteRead6050(unsigned char REG_Address)
{
    unsigned char REG_data;
    IIC_start();                   //璧峰淇″彿
    IIC_writebyte(SlaveAddress);     //鍙戦�佽澶囧湴鍧�+鍐欎俊鍙�
    IIC_writebyte(REG_Address);      //鍙戦�佸瓨鍌ㄥ崟鍏冨湴鍧�锛屼粠0寮�濮�
    IIC_start();                   //璧峰淇″彿
    IIC_writebyte(SlaveAddress+1);  //鍙戦�佽澶囧湴鍧�+璇讳俊鍙�
    REG_data=IIC_readebyte();       //璇诲嚭瀵勫瓨鍣ㄦ暟鎹�
    SendACK(1);                //鎺ユ敹搴旂瓟淇″彿
    IIC_stop();                    //鍋滄淇″彿
    return REG_data;
}
//**************************************
//鍚堟垚鏁版嵁
//**************************************
int Get6050Data(unsigned char REG_Address)
{
    char H,L;
    H=ByteRead6050(REG_Address);
    L=ByteRead6050(REG_Address+1);
    return (H<<8)+L;   //鍚堟垚鏁版嵁
}
//**************************************
//鍒濆鍖朚PU6050
//**************************************
void InitMPU6050()
{
    ByteWrite6050(PWR_MGMT_1, 0x00);  // 瑙ｉ櫎浼戠湢鐘舵��
    ByteWrite6050(SMPLRT_DIV, 0x07);  // 闄�铻轰华閲囨牱鐜囪缃紙125HZ锛�
    ByteWrite6050(CONFIG, 0x06);      // 浣庨�氭护娉㈠櫒璁剧疆锛�5HZ棰戠巼锛�
    ByteWrite6050(GYRO_CONFIG, 0x18); // 闄�铻轰华鑷鍙婃娴嬭寖鍥磋缃�(涓嶈嚜妫�,16.4LSB/DBS/S)
    ByteWrite6050(ACCEL_CONFIG, 0x01); // 涓嶈嚜妫�锛岄噺绋�2g
}

/*
**********************************************
**鍑芥暟鍚�  锛歠loat Mpu6050AccelAngle(int8 dir)
**鍑芥暟鍔熻兘锛氳緭鍑哄姞閫熷害浼犳劅鍣ㄦ祴閲忕殑鍊捐鍊�
**            鑼冨洿涓�2g鏃讹紝鎹㈢畻鍏崇郴锛�16384 LSB/g
**            瑙掑害杈冨皬鏃讹紝x=sinx寰楀埌瑙掑害锛堝姬搴︼級, deg = rad*180/3.14
**            鍥犱负x>=sinx,鏁呬箻浠�1.2閫傚綋鏀惧ぇ
**杩斿洖鍙傛暟锛氭祴閲忕殑鍊捐鍊�
**浼犲叆鍙傛暟锛歞ir - 闇�瑕佹祴閲忕殑鏂瑰悜
**           ACCEL_XOUT - X鏂瑰悜
**           ACCEL_YOUT - Y鏂瑰悜
**           ACCEL_ZOUT - Z鏂瑰悜
**********************************************
*/
float Mpu6050AccelAngle(signed char dir)
{
    float accel_agle; // 娴嬮噺鐨勫�捐鍊�
    float result; // 娴嬮噺鍊肩紦瀛樺彉閲�
    result = (float)Get6050Data(dir); // 娴嬮噺褰撳墠鏂瑰悜鐨勫姞閫熷害鍊�,杞崲涓烘诞鐐规暟
    accel_agle = (result + MPU6050_ZERO_ACCELL)/16384; // 鍘婚櫎闆剁偣鍋忕Щ,璁＄畻寰楀埌瑙掑害锛堝姬搴︼級
    accel_agle = accel_agle*1.2*180/3.14;     //寮у害杞崲涓哄害

    return accel_agle; // 杩斿洖娴嬮噺鍊�
}

/*
**********************************************
**鍑芥暟鍚�  锛歠loat Mpu6050GyroAngle(int8 dir)
**鍑芥暟鍔熻兘锛氳緭鍑洪檧铻轰华娴嬮噺鐨勫�捐鍔犻�熷害
**            鑼冨洿涓�2000deg/s鏃讹紝鎹㈢畻鍏崇郴锛�16.4 LSB/(deg/s)
**杩斿洖鍙傛暟锛氭祴閲忕殑鍊捐鍔犻�熷害鍊�
**浼犲叆鍙傛暟锛歞ir - 闇�瑕佹祴閲忕殑鏂瑰悜
**           GYRO_XOUT - X杞存柟鍚�
**           GYRO_YOUT - Y杞存柟鍚�
**           GYRO_ZOUT - Z杞存柟鍚�
**********************************************
*/
float Mpu6050GyroAngle(signed char dir)
{
    float gyro_angle;
    gyro_angle = (float)Get6050Data(dir);   // 妫�娴嬮檧铻轰华鐨勫綋鍓嶅��
    gyro_angle = -(gyro_angle + MPU6050_ZERO_GYRO)/16.4;    //鍘婚櫎闆剁偣鍋忕Щ锛岃绠楄閫熷害鍊�,璐熷彿涓烘柟鍚戝鐞�

    return gyro_angle; // 杩斿洖娴嬮噺鍊�
}

void MPU6050_display(void)
{
    a=Mpu6050AccelAngle(ACCEL_XOUT);
    b=Mpu6050AccelAngle(ACCEL_YOUT);
    c=Mpu6050AccelAngle(ACCEL_ZOUT);

    OLED_Refresh();
    if(a>=0) OLED_ShowString(20,7," X = ",16,1);
    else     OLED_ShowString(20,7," X =-",16,1);

    if(b>=0) OLED_ShowString(20,24," Y = ",16,1);
    else     OLED_ShowString(20,24," Y =-",16,1);

    if(c>=0) OLED_ShowString(20,41," Z = ",16,1);
    else     OLED_ShowString(20,41," Z =-",16,1);


    OLED_ShowNum(60,7,abs(a),2,16,1);
    OLED_ShowNum(60,24,abs(b),2,16,1);
    OLED_ShowNum(60,41,abs(c),2,16,1);
    OLED_Refresh();
}
