/*
 * huidu.h
 *
 *  Created on: 2023��5��28��
 *      Author: 29054
 */

#ifndef HARDWARE_HUIDU_H_
#define HARDWARE_HUIDU_H_

void HuiDu_Init(void);

#endif /* HARDWARE_HUIDU_H_ */
