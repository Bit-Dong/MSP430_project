/*
 * uart.h
 *
 *  Created on: 2023��5��11��
 *      Author: 29054
 */

#ifndef HARDWARE_UART_H_
#define HARDWARE_UART_H_


void UARTInit();
void FS(unsigned char*write);
void FSNO(unsigned char*write);
void HS(int a);



#endif /* HARDWARE_UART_H_ */
