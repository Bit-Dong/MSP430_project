/*
 * judge.h
 *
 *  Created on: 2023��6��2��
 *      Author: 29054
 */

#ifndef HARDWARE_JUDGE_H_
#define HARDWARE_JUDGE_H_


void xunji(void);
void judge1(void);
void judge2(void);
void judge3(void);
void judge4(void);
void judge5(void);
void judge6(void);
void judge7(void);
void judge8(void);



#endif /* HARDWARE_JUDGE_H_ */
