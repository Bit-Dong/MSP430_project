#include "msp430f5529.h"
#include "bluetooth.h"

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����
#define delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))

// ACLK = REFO = 32768Hz, MCLK = SMCLK = default DCO/2 = 1048576Hz
// P3.4��5����USCI_A0 TXD/RXD��P9.4,5����USCI_A2 TXD/RXD��P10.4,5����USCI_A3 TXD/RXD��

void blue_init(void){
    P4SEL |=BIT4+BIT5 ;                             // P4.5 P4.4 = USCI_A1 TXD/RXD
    UCA1CTL1 |= UCSWRST;                      // **Put state machine in reset**
    UCA1CTL1 |= UCSSEL_2;                     // SMCLK
    UCA1BR0 = 9;                              // 1MHz 115200 (see User's Guide)
    UCA1BR1 = 0;                              // 1MHz 115200
    UCA1MCTL |= UCBRS_1 + UCBRF_0;            // Modulation UCBRSx=1, UCBRFx=0
    UCA1CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
    UCA1IE &= ~UCRXIE;                         // �ر�UART1�Ľ����ж�
    __enable_interrupt(); // ����ȫ���ж�
}

