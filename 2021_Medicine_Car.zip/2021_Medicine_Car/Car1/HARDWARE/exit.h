/*
 * exit.h
 *
 *  Created on: 2023��5��11��
 *      Author: 29054
 */

#ifndef HARDWARE_EXIT_H_
#define HARDWARE_EXIT_H_


#include <msp430.h>
void init_encoders();


#endif /* HARDWARE_EXIT_H_ */
