/*
 * motor.h
 *
 *  Created on: 2023��3��30��
 *      Author: 29054
 */

#ifndef HARDWARE_MOTOR_H_
#define HARDWARE_MOTOR_H_


void motor_gpio_init(void);

void head(void);
void back(void);
void stop(void);
void L_back(void);
void R_back(void);
void L_head(void);
void R_head(void);
void left(void);
void right();
#endif /* HARDWARE_MOTOR_H_ */
