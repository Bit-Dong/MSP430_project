/*
 * clk.h
 *
 *  Created on: 2023��5��11��
 *      Author: 29054
 */

#ifndef HARDWARE_CLK_H_
#define HARDWARE_CLK_H_


void clk_Init ();


#endif /* HARDWARE_CLK_H_ */
