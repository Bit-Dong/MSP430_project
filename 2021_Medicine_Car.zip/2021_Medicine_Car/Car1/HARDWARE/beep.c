#include "beep.h"

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����
#define delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))
void beep_init()
{
    P8SEL &= ~BIT2; //����
    P8DIR |= BIT2;
    P8SEL &= ~BIT1; //����
    P8DIR |= BIT1;
    P8OUT &=~BIT2;
    P8OUT &=~BIT1;

}


void Beep(){
    P8OUT |=BIT2;
    P8OUT |=BIT1;
    delay_ms(10);
    P8OUT &=~BIT2;
    P8OUT &=~BIT1;
    delay_ms(10);
}
