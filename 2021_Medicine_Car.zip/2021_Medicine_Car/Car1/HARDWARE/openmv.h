/*
 * openmv.h
 *
 *  Created on: 2023��5��29��
 *      Author: 29054
 */

#ifndef HARDWARE_OPENMV_H_
#define HARDWARE_OPENMV_H_

void openmv_init(void);



#endif /* HARDWARE_OPENMV_H_ */
