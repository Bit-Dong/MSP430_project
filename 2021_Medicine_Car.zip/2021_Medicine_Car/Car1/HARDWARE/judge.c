/*
 * judge.c
 *
 *  Created on: 2023��6��2��
 *      Author: 29054
 */
#include "judge.h"
#include <HARDWARE/motor.h>
#include <HARDWARE/timer.h>
#include <HARDWARE/pwm.h>
#include <HARDWARE/huidu.h>
#include <msp430.h>
#include "msp430f5529.h"
#include <HARDWARE/oled.h>
#include <HARDWARE/bluetooth.h>

#define CPU_F ((double)1000000)
#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))//���¶�����ʱ����

int pill=0;
int flag1=0;
int flag2=0;
int flag3=0;
int flag4=0;
int flag5=0,flag55=0;
int flag6=0,flag66=0;
int flag7=0,flag77=0;
int flag8=0,flag88=0;


void xunji()
{
    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)!=BIT3))    //��3����3��û�ȵ����вȵ�
    {
        head();
        SetPwm_Init(24,1000,500);//���
        SetPwm_Init(25,1000,500);//�ұ�
    }
    else if(((P6IN&BIT1)==BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3))   //��3�ȵ�
    {
        head();
        SetPwm_Init(24,1000,0);//���
        SetPwm_Init(25,1000,500);//�ұ�
    }
    else if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)==BIT3))  //��3�ȵ�
    {
        head();
        SetPwm_Init(24,1000,500);//���
        SetPwm_Init(25,1000,0);//�ұ�
    }
    else if(((P6IN&BIT1)==BIT1) && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)!=BIT3))   //��3���вȵ�
    {
        head();
        SetPwm_Init(24,1000,300);//���
        SetPwm_Init(25,1000,500);//�ұ�
    }
    else if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))   //��3���вȵ�
    {
        head();
        SetPwm_Init(24,1000,500);//���
        SetPwm_Init(25,1000,300);//�ұ�

    }
    else if(((P6IN&BIT5)!=BIT5) && ((P6IN&BIT0)!=BIT0) && ((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && ((P6IN&BIT4)!=BIT4) && ((P7IN&BIT0)==BIT0))   //��3���вȵ�
    {
        head();
        SetPwm_Init(24,1000,600);//���
        SetPwm_Init(25,1000,0);//�ұ�

    }
    else if(((P6IN&BIT5)==BIT5) && ((P6IN&BIT0)!=BIT0) && ((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && ((P6IN&BIT4)!=BIT4) && ((P7IN&BIT0)!=BIT0))   //��3���вȵ�
    {
        head();
        SetPwm_Init(24,1000,0);//���
        SetPwm_Init(25,1000,600);//�ұ�

    }
    else if(((P6IN&BIT5)!=BIT5) && ((P6IN&BIT0)==BIT0) && ((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && ((P6IN&BIT4)!=BIT4) && ((P7IN&BIT0)!=BIT0))   //��3���вȵ�
    {
        head();
        SetPwm_Init(24,1000,0);//���
        SetPwm_Init(25,1000,600);//�ұ�

    }
    else if(((P6IN&BIT5)!=BIT5) && ((P6IN&BIT0)!=BIT0) && ((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && ((P6IN&BIT4)==BIT4) && ((P7IN&BIT0)!=BIT0))   //��3���вȵ�
    {
        head();
        SetPwm_Init(24,1000,600);//���
        SetPwm_Init(25,1000,0);//�ұ�

    }

}

void judge1(void)
{
    xunji();

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        if(flag1==-100)
        {
            UCA1TXBUF='a';
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        flag1++;
        if(flag1==1)
        {
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            flag1=-100;
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));

        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }

}


void judge2(void)
{
    xunji();

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        if(flag2==-100)
        {
            UCA1TXBUF='a';
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);

        }
        flag2++;
        if(flag2==1)
        {
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            flag2=-100;
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));
        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }

}

void judge3(void)
{
    xunji();

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        if(flag3==-100)
        {
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            UCA1TXBUF='a';
        }
        flag3++;
        if(flag3==1)    
		{
			delay_us(150000);
		}
        if(flag3>=2&& flag3<=6)
        {
            flag3=10;
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            flag3=-100;
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));
        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }

}

void judge4(void)
{
    xunji();

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        if(flag4==-100)
        {
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            UCA1TXBUF='a';
        }
        flag4++;
        if(flag4==1)    
		{
			delay_us(150000);
		}
        if(flag4>=2&& flag4<=6)
        {
            flag4=10;
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            flag4=-100;
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));
        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }
}

void judge5(void)
{
    xunji();

    if(flag55!=0)
    {
        if(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1))&&flag55==1)
        {
            while(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1)));
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            flag55++;
            UCA1TXBUF='a';
        }
        if(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)==BIT0) && (((P6IN&BIT3)==BIT3)||((P6IN&BIT2)==BIT2))&&flag55==2)
        {
            while(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)==BIT0) && (((P6IN&BIT3)==BIT3)||((P6IN&BIT2)==BIT2)));
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            flag55=0;
        }

    }

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        delay_us(10000);
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        flag5++;
        if(flag5==1 || flag5==2)    delay_us(150000);
        if(flag5>=3&& flag5<=6)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag5=10;
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        if(flag5>10)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag5=-100;
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));

    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));
            flag55=1;
        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }
}

void judge6(void)
{
    xunji();

    if(flag66!=0)
    {
        if(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1))&&flag66==1)
        {
            while(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1)));
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            flag66++;
            UCA1TXBUF='a';
        }
        if(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1))&&flag66==2)
        {
            while(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1)));
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            flag66=0;
        }
    }

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        flag6++;
        if(flag6==1 || flag6==2)    delay_us(150000);
        if(flag6>=3&& flag6<=6)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag6=10;
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        if(flag6>10)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag6=-100;
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));

    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));
            flag66=1;
        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }
}

void judge7(void)
{
    xunji();

    if(flag77!=0)
    {
        if(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)==BIT0) && (((P6IN&BIT3)==BIT3)||((P6IN&BIT2)==BIT2))&&flag77==1)
        {
            while(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)==BIT0) && (((P6IN&BIT3)==BIT3)||((P6IN&BIT2)==BIT2)));
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);

            flag77++;
            UCA1TXBUF='a';
        }
        if(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)==BIT0) && (((P6IN&BIT3)==BIT3)||((P6IN&BIT2)==BIT2))&&flag77==2)
        {
            while(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1)));
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            flag77=0;
        }
    }

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        flag7++;
        if(flag7==1 || flag7==2)    delay_us(150000);
        if(flag7>=3&& flag7<=6)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag7=10;
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        if(flag7>10)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag7=-100;
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));

    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));
            flag77=1;
        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }
}



void judge8(void)
{
    xunji();

    if(flag88!=0)
    {

        if(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)==BIT0) && (((P6IN&BIT3)==BIT3)||((P6IN&BIT2)==BIT2))&&flag88==1)
        {
            while(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)==BIT0) && (((P6IN&BIT3)==BIT3)||((P6IN&BIT2)==BIT2)));
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            flag88++;
            UCA1TXBUF='a';
        }
        if(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1))&&flag88==2)
        {
            while(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)!=BIT0) && (((P6IN&BIT2)==BIT2)||((P6IN&BIT1)==BIT1)));
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
            flag88=0;
        }
    }

    if(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3))
    {
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
        flag8++;
        if(flag8==1 || flag8==2)    delay_us(150000);
        if(flag8>=3&& flag8<=6)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag8=10;
            right();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        if(flag8>10)
        {
            while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));
            flag8=-100;
            left();
            SetPwm_Init(24,1000,700);//���
            SetPwm_Init(25,1000,700);//�ұ�
            delay_us(300000);
        }
        while(((P6IN&BIT1)==BIT1)  && ((P6IN&BIT2)==BIT2) && ((P6IN&BIT3)==BIT3));

    }

    if(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)) || (((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)!=BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0))||(((P6IN&BIT5)!=BIT5)  && ((P6IN&BIT0)==BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)!=BIT2) &&((P6IN&BIT3)==BIT3) &&((P6IN&BIT4)!=BIT4)&&((P7IN&BIT0)==BIT0))||(((P6IN&BIT5)==BIT5)  && ((P6IN&BIT0)!=BIT0) &&((P6IN&BIT1)==BIT1)&&((P6IN&BIT2)==BIT2) &&((P6IN&BIT3)!=BIT3) &&((P6IN&BIT4)==BIT4)&&((P7IN&BIT0)!=BIT0)))
    {
        if( pill==0 && ((P7IN&BIT4)==BIT4) )     //����ҩƷ
        {
            pill=1;
            back();
            SetPwm_Init(24,1000,400);//���
            SetPwm_Init(25,1000,400);//�ұ�
            delay_us(700000);
            left();
            SetPwm_Init(24,1000,550);//���
            SetPwm_Init(25,1000,650);//�ұ�
            delay_us(700000);
            while(((P6IN&BIT1)!=BIT1) && ((P6IN&BIT2)!=BIT2) && ((P6IN&BIT3)!=BIT3) && (((P7IN&BIT0)!=BIT0)||((P6IN&BIT5)!=BIT5)) && (((P6IN&BIT0)!=BIT0)||((P6IN&BIT4)!=BIT4)));
            flag88=1;
        }
        else
        {
            stop();
            SetPwm_Init(24,1000,0);//���
            SetPwm_Init(25,1000,0);//�ұ�
        }
    }
}


/* --------------   �����ж�(����ͨ��)    ----------------*/
 //Echo back RXed character, confirm TX buffer is ready first����������֮ǰȷ�����ͻ���׼����
//#pragma vector=USCI_A1_VECTOR
//__interrupt void USCI_A1_ISR(void)
//{
//  switch(__even_in_range(UCA1IV,4))
//  {
//
//  case 0:     //���ж�
//      break;                             // Vector 0 - no interrupt
//  case 2:                                   // Vector 2 - RXIFG  �����ж�
//
//   while (!(UCA1IFG&UCTXIFG));    // USCI_A1 TX buffer ready?   UCTXIFG(USCI Transmit Interrupt Flag)
//                                   //�ȴ����ݷ������ ���UCTXIFG��1 ����ѭ��
////    UCA1TXBUF = UCA1RXBUF;                  // TX -> RXed character
//
////   if(UCA1RXBUF=='2'){
////
////   }
//
//   break;
//  case 4:
//      break;                             // Vector 4 - TXIFG  �����ж�
//
//  default: break;
//  }
//}
// UCTXIFG=0x02��UCA1IFG&UCTXIFG����UCA1IFG��UCTXIFGλΪ1ʱ��˵��UCA1TXBUFΪ�գ�
//����whileѭ��ѭ������UCTXIFGλΪ0ʱUCA1TXBUF��Ϊ�գ�ͣ��ѭ����
