/*
 * huidu.c
 *
 *  Created on: 2023��5��28��
 *      Author: 29054
 */

#include <msp430.h>
#include "huidu.h"



void HuiDu_Init(void)
{
    P6SEL &=~BIT0;
    P6DIR &=~BIT0;
    P6REN |=BIT0;

    P6SEL &=~BIT1;
    P6DIR &=~BIT1;
    P6REN |=BIT1;

    P6SEL &=~BIT2;
    P6DIR &=~BIT2;
    P6REN |=BIT2;

    P6SEL &=~BIT3;
    P6DIR &=~BIT3;
    P6REN |=BIT3;

    P6SEL &=~BIT4;
    P6DIR &=~BIT4;
    P6REN |=BIT4;

    P6SEL &=~BIT5;
    P6DIR &=~BIT5;
    P6REN |=BIT5;

    P7SEL &=~BIT0;
    P7DIR &=~BIT0;
    P7REN |=BIT0;

}


