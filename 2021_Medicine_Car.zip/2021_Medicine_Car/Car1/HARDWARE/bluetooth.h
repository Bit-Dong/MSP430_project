/*
 * bluetooth.h
 *
 *  Created on: 2023��3��31��
 *      Author: 29054
 */

#ifndef HARDWARE_BLUETOOTH_H_
#define HARDWARE_BLUETOOTH_H_


void blue_init(void);


#endif /* HARDWARE_BLUETOOTH_H_ */
