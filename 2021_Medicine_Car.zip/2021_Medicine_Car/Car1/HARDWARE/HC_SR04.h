/*
 * HC_SR04.h
 *
 *  Created on: 2023��3��30��
 *      Author: 29054
 */

#ifndef HARDWARE_HC_SR04_H_
#define HARDWARE_HC_SR04_H_

#include "msp430f5529.h"
#include "stdio.h"

#define    TRIG          BIT4
#define    ECHO          BIT2   //P1.1 DIR.0=0 + SEL.1=1 + SEL2.1=0 --> TA0.CCI0A
#define    USOUND_DIR    P1DIR
#define    USONUD_OUT    P1OUT
#define    USOUND_IE     P1IE
#define    USOUND_IES    P1IES
#define    USOUND_SEL    P1SEL
extern float  distance;
void  sr04_init();
float GetDistance();



#endif /* HARDWARE_HC_SR04_H_ */
