#include "msp430f5529.h"
#include <HARDWARE/pwm.h>

void motor_gpio_init(void){
      P3SEL &= ~BIT0; //����
      P3DIR |= BIT0;
      P3SEL &= ~BIT1;
      P3DIR |= BIT1;

      P3SEL &= ~BIT5; //����
      P3DIR |= BIT5;
      P3SEL &= ~BIT6;
      P3DIR |= BIT6;

      P3OUT |=BIT0;
      P3OUT |=BIT1;
      P3OUT |=BIT5;
      P3OUT |=BIT6;

}


void head(void){
    P3OUT |= BIT5;P3OUT &=~ BIT6;  //������ת
    P3OUT &=~ BIT1;P3OUT |= BIT0;  //������ת
}

void back(void){
    P3OUT &=~ BIT5;P3OUT |= BIT6;  //��
    P3OUT |= BIT1 ;P3OUT &=~ BIT0; //��
}

void stop(void){
    P3OUT |=BIT0;   P3OUT |=BIT1;
    P3OUT |=BIT5;   P3OUT |=BIT6;
}

void L_back(void){
    P3OUT &=~ BIT5;P3OUT |= BIT6;  //��
}

void R_back(void){
    P3OUT |= BIT1 ;P3OUT &=~ BIT0; //��
}

void L_head(void){
    P3OUT |= BIT5;P3OUT &=~ BIT6;  //������ת
}

void R_head(void){
    P3OUT &=~ BIT1;P3OUT |= BIT0;  //������ת
}

void left(void)
{
    P3OUT &=~ BIT5;P3OUT |= BIT6;  //��
    P3OUT &=~ BIT1;P3OUT |= BIT0;  //������ת
}

void right(void)
{
    P3OUT |= BIT1 ;P3OUT &=~ BIT0; //��
    P3OUT |= BIT5 ;P3OUT &=~ BIT6;  //������ת
}
