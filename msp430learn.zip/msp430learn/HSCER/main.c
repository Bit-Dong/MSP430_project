#include <msp430.h> 
//lcd��ʼ������
#include "HARDWARE/LCD/type.h"
#include "HARDWARE/LCD/timeup.h"
#include "HARDWARE/LCD/QDTFT_demo.h"
#include "HARDWARE/LCD/Lcd_Driver.h"
#include "HARDWARE/LCD/GUI.h"
//#include "HARDWARE/LCD/Picture.h"

#include "HARDWARE/hscer.h"


unsigned int cap_new = 0;           // �״β�׽��ta0rֵ
unsigned int cap_old = 0;           // �ڶ��β�׽��ta0rֵ

char cap_N = 0;                     // �������
char state = 0x00;                  // ״̬
u16 cap_data ;                  // ����ֵ��u16


/**
 * main.c
 */
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
    upVcc();//��ѹ
    timerup();//ʱ��Ƶ����Ϊ25MHZ
    Lcd_Init();
    LCD_LED_SET;//ͨ��IO���Ʊ�����
    Lcd_Clear(WHITE); //����
    Hscer_Init();
    __bis_SR_register(GIE);//�����ж�
    Gui_DrawFont_GBK16(10,0,BLUE,GRAY0,"����2��");
    Gui_DrawFont_GBK16(10,20,BLUE,GRAY0,"Dis:");
    Gui_DrawFont_GBK24(100,60,BLUE,GRAY0,"CM");
    while(1){

        Hc_sr_Open();

        __delay_cycles(1000000);
    }
}


#pragma vector=TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{

    switch(__even_in_range(TA0IV,14))//�������range��������Ϊ��ʹswitch����Ч�ʸ�
    {
      case  0:break;                                 // No interrupt
      case  2:
          state =  TA0CCTL1 >> 14;
          TA0CCTL1 &= ~CCIFG;//��־λ����
          if( TA0CCTL1 & CM_1){//��ʼ����ߵ�ƽʱ��
              cap_new = TA0CCR1;
              TA0CCTL1 &= ~CM_1;
              TA0CCTL1 |=  CM_2;
          }else if ( TA0CCTL1 & CM_2){
              cap_old = TA0CCR1;
              cap_data = ( cap_old - cap_new ) * 0.34/10/6.25;//����������ͣ�
              Gui_DrawFont_Num32(10,50,BLUE,GRAY0,cap_data/100);//��ʾ����
              Gui_DrawFont_Num32(37,50,BLUE,GRAY0,cap_data/10%10);
              Gui_DrawFont_Num32(64,50,BLUE,GRAY0,cap_data%10);


              TA0CCTL1 &= ~CM_2;
              TA0CCTL1 |=  CM_1;
          }else
          break;                           // CCR1 not used
      case  4: break;                          // CCR2 not used
      case  6: break;                          // reserved
      case  8: break;                          // reserved
      case 10: break;                          // reserved
      case 12: break;                          // reserved
      case 14:
          TA0CTL &= ~TAIFG;
          if(cap_old   < cap_new ){
              cap_N += 1;
          }
          break;                          // overflow
      default: break;
    }
}
