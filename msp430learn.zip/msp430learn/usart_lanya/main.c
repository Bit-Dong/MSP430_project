#include <msp430.h>
//#include <io430.h>
void delay(int ms)        //��ʱ����
{
    int i,j;
    for( i=0;i<ms;i++)
    for( j=0;j<240;j++);
}

void send_buf(unsigned char *ptr)    //�����ַ���
{
    while(*ptr != '\0')
    {
        while(!(UCA0IFG & UCTXIFG));
        UCA0TXBUF = *ptr;
        ptr++;
        delay(50);
    }
}

void main(void)
{
    WDTCTL = WDTPW + WDTHOLD;      //�رտ��Ź�

    P4DIR |= BIT7;                               //��ʼ��LED

    //���ڳ�ʼ��
     P3SEL    |=  BIT3+BIT4;                       // P5.6,7 = USCI_A1 TXD/RXD
     UCA0CTL1 |=  UCSWRST;                      // **Put state machine in reset**
     UCA0CTL1 |=  UCSSEL_1;                     // ACLK
     UCA0BR0   =  0x03;                         // 32768Hz 9600 ������Ϊ9600
     UCA0BR1   =  0x00;                             // 32768Hz 9600
     UCA0MCTL |=  UCBRS_3 + UCBRF_0;           // Modulation UCBRSx=1, UCBRFx=0  ok
     //UCA0MCTL = UCBRS_0 + UCBRF_13 + UCOS16;
     UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
     UCA0IE |=  UCRXIE;                       // Enable USCI_A1 RX interrupt ʹ���ж�

     //S2  ok
    P2IE |= BIT1;
    P2IES |= BIT1;
    P2IFG &= ~ BIT1;
    P2REN |= BIT1;
    P2OUT |= BIT1;
    _EINT();                                               //�ж�ʹ��
   // send_buf("����ͨ��\r\n");
    //send_buf("jecaa\r\n");
    while(1)
    {
        //send_buf("jecaa\r\n");
        delay(500);


    }
}
int A=0;
#pragma vector = USCI_A0_VECTOR
__interrupt void USCI_A0()
{
    A++;
    switch(_even_in_range(UCA0IV,4))
    {
    case 0:break;                             // Vector 0 - No interrupt
        case 2:                                   // Vector 2 - RXIFG
           // UCA0TXBUF = UCA0RXBUF;                // ���ͽ��յ�������
                                     // ����Է�����Ϣ���д����޸Ĵ˴�
            break;
     case 4:break;                             // Vector 4 - TXIFG
     default: break;
    }
}
int b=0;
#pragma vector = PORT2_VECTOR
__interrupt void P2_ISR()
{
    b++;
    if(P2IFG & BIT1)
    {
        while((P2IN & BIT1)==0);
        P4OUT ^= BIT7;
        send_buf("wgwg");
    }
    P2IFG &=~ BIT1;
}
