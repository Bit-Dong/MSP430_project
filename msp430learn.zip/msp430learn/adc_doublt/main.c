#include <msp430.h>
#include <HARDWARE/oled.h>
#include <HARDWARE/adc_double.h>

#define Num_of_Results 8

volatile unsigned int A0results[Num_of_Results];
volatile unsigned int A1results[Num_of_Results];
volatile unsigned int A2results[Num_of_Results];
volatile unsigned int A3results[Num_of_Results];

int main(void)
{
    OLED_Init();
    OLED_ShowString(0,0,"ADC",16,1);
    OLED_Refresh();
    ADC_double_Init( );
    while(1)
    {

        __bis_SR_register(LPM0_bits + GIE);       //����LPM0������ȫ���ж�
        __no_operation();               //���ڵ�������ϵ�
    }

}

#pragma vector=ADC12_VECTOR
__interrupt void ADC12ISR (void)
{
    static unsigned int index = 0;

    switch(__even_in_range(ADC12IV,34))
    {
    case  0: break;                           // Vector  0:  No interrupt
    case  2: break;                           // Vector  2:  ADC overflow
    case  4: break;                           // Vector  4:  ADC timing overflow
    case  6: break;                           // Vector  6:  ADC12IFG0
    case  8: break;                           // Vector  8:  ADC12IFG1
    case 10: break;                           // Vector 10:  ADC12IFG2
    case 12:                                  // Vector 12:  ADC12IFG3
        A0results[index] = ADC12MEM0;         // Move A0 results, IFG is cleared
        A1results[index] = ADC12MEM1;         // Move A1 results, IFG is cleared
        A2results[index] = ADC12MEM2;         // Move A2 results, IFG is cleared
        A3results[index] = ADC12MEM3;         // Move A3 results, IFG is cleared
        index++;                              // ���浽���������

        if (index == 8)
        {
            (index = 0);
        }
        OLED_ShowString(0,16,"ADC0=",16,1);
        OLED_ShowNum(40,16,ADC12MEM0,4,16,1);
        OLED_ShowString(0,32,"ADC1=",16,1);
        OLED_ShowNum(40,32,ADC12MEM1,4,16,1);
        OLED_ShowString(0,48,"ADC2=",16,1);
        OLED_ShowNum(40,48,ADC12MEM2,4,16,1);
        OLED_Refresh();
        __bic_SR_register_on_exit(LPM0_bits); //�˳�LPM0ģʽ
    case 14: break;                           // Vector 14:  ADC12IFG4
    case 16: break;                           // Vector 16:  ADC12IFG5
    case 18: break;                           // Vector 18:  ADC12IFG6
    case 20: break;                           // Vector 20:  ADC12IFG7
    case 22: break;                           // Vector 22:  ADC12IFG8
    case 24: break;                           // Vector 24:  ADC12IFG9
    case 26: break;                           // Vector 26:  ADC12IFG10
    case 28: break;                           // Vector 28:  ADC12IFG11
    case 30: break;                           // Vector 30:  ADC12IFG12
    case 32: break;                           // Vector 32:  ADC12IFG13
    case 34: break;                           // Vector 34:  ADC12IFG14
    default: break;
  }
}
