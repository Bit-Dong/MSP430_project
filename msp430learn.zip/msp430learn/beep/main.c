#include <msp430.h> 
#include "HARDWARE/beep.h"
#include "HARDWARE/delay.h"
#include "HARDWARE/anjian.h"
#include "HARDWARE/led.h"

/**
 * main.c
 */
int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	BEEP_Init();
	LED_Init();
	ANJIAN_Init();
	//delay_ms(1000);
	while(1)
	{

    if((P1IN&BIT1)==0)
    {
        BEEP_Two(); //��������������
        P1OUT|=BIT0;
        delay_ms(1000);
    }
        P1OUT&=~BIT0;

	}

	
}
