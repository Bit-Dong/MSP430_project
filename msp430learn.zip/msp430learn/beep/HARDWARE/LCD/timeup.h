/*
 * timeup.h
 *
 *  Created on: 2021��8��1��
 *      Author: 14579
 */

#ifndef TIMEUP_H_
#define TIMEUP_H_


void timerup(void);
void upVcc(void);


#endif /* TIMEUP_H_ */
