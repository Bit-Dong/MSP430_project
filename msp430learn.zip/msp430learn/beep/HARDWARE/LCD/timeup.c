/*
 * timeup.c
 *
 *  Created on: 2021��8��1��
 *      Author: 14579
 */
#include "msp430.h"
#include "timeup.h"
void upVcc(void)//���ĵ�ѹ����
{
    PMMCTL0_H = 0xA5;
    SVSMLCTL |= SVSMLRRL_1 + SVMLE;
    PMMCTL0 = PMMPW +PMMCOREV_3;
    while((PMMIFG & SVSMLDLYIFG)==0);
    PMMIFG &=~ (SVMLVLRIFG + SVMLIFG + SVSMLDLYIFG);
    if((PMMIFG & SVMLIFG)==1)
        while((PMMIFG & SVMLVLRIFG)==0);
    SVSMLCTL &=~ SVMLE;
    PMMCTL0_H = 0x00;
}
void timerup(void)//����ʱ��25MHZ
{

UCSCTL3 = SELREF_2;
UCSCTL4 |= SELA_2;
__bis_SR_register(SCG0);
UCSCTL0 = 0x0000;
UCSCTL1 = DCORSEL_7;//50Mhz��Χ
UCSCTL2 = FLLD_0 + 762;    //(762+1)*32768==25MHZ
__bic_SR_register(SCG0);

__delay_cycles(782000);

while(SFRIFG1 & OFIFG)
{
    UCSCTL7 &=~ (XT2OFFG + XT1LFOFFG + DCOFFG);
    SFRIFG1 &=~ OFIFG;

}
//UCSCTL4 = UCSCTL4&(~(SELS_7|SELM_7))|SELS_3|SELM_3;
}

