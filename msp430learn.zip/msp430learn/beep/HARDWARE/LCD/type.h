/*
 * type.h
 *
 *  Created on: 2021��7��31��
 *      Author: 14579
 */

#ifndef TYPE_H_
#define TYPE_H_

#define u32 unsigned int
#define u16 unsigned short
#define u8 unsigned char



#endif /* TYPE_H_ */
