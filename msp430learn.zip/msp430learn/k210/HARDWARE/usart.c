/*
 * usart.c
 *
 *  Created on: 2022��6��30��
 *      Author: lenovo
 */
#include "usart.h"
#include "led.h"
#include "delay.h"

void USART_init(void)
{
    P4SEL|=BIT4+BIT5;                          //P5.6,7=USCI_AI TXD/RXD
    UCA1CTL1|=UCSWRST;                         //��λ
    UCA1CTL1|=UCSSEL_2;                        //SMCLK
    UCA1BR0=104;                                 //1MHZ 11520
    UCA1BR1=0;                                 //1MHZ 11520
    UCA1MCTL|=UCBRS_1+UCBRF_0;                 //Modulation BCBRSX=1,UCBRFX=0
    UCA1CTL1&=~UCSWRST;                        //USCI STATE MACHINE
    UCA1IE|=UCRXIE;                            //ENABLE USCI_A1 RX INTERRUPT
}



//void Usart_Init(void)//���ڳ�ʼ������������115200
//{
//    P4SEL |=BIT4+BIT5 ;                             // P5.6,7 = USCI_A1 TXD/RXD
//    UCA1CTL1 |= UCSWRST;                      // **Put state machine in reset**
//    UCA1CTL1 |= UCSSEL_2;                     // SMCLK
//    UCA1BR0 = 9;                              // 1MHz 115200 (see User's Guide)
//    UCA1BR1 = 0;                              // 1MHz 115200
//    UCA1MCTL |= UCBRS_1 + UCBRF_0;            // Modulation UCBRSx=1, UCBRFx=0
//    UCA1CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
//    UCA1IE |= UCRXIE;                         // Enable USCI_A1 RX interrupt
//    //__bis_SR_register(LPM0_bits + GIE);       // Enter LPM0, interrupts enabled
//    _EINT();
//}
void Usart1_Init(void)           //���ڳ�ʼ��9600
{
    P4SEL |= BIT4+BIT5;
     UCA1CTL1 |= UCSWRST;
     UCA1CTL1 |= UCSSEL_1;        //ACLK ��ʱ��32768HZ

     UCA1BR0 = 0x03;
     UCA1BR1 = 0x00;                //32768HZ  9600baud
     UCA1MCTL |= UCBRS_3 + UCBRF_0;

     UCA1CTL1 &=~ UCSWRST;
     UCA1IE |= UCRXIE;        //open interrupt of

     _EINT();
}

void send1_buf(unsigned char *ptr)    //�����ַ���
{
    while(*ptr != '\0')
    {
        while(!(UCA1IFG & UCTXIFG));
        UCA1TXBUF = *ptr;
        ptr++;
        delay_ms(10);
    }
}
////һ��Ϊ�жϷ�����
//// Echo back RXed character, confirm TX buffer is ready first����������֮ǰȷ�����ͻ���׼����
//#pragma vector=USCI_A1_VECTOR
//__interrupt void USCI_A1_ISR(void)
//{
//    unsigned char BUF;
//  switch(__even_in_range(UCA1IV,4))
//  {
//  case 0:break;                             // Vector 0 - no interrupt
//  case 2:                                   // Vector 2 - RXIFG
//   while (!(UCA1IFG&UCTXIFG));    // USCI_A1 TX buffer ready?   UCTXIFG(USCI Transmit Interrupt Flag)
//                                   //�ȴ����ݷ������ ���UCTXIFG��1 ����ѭ��
//    //UCA1TXBUF = UCA1RXBUF;                  // TX -> RXed character
//    BUF = UCA1RXBUF;
//    UCA1TXBUF = UCA1RXBUF;
//    if(BUF=='1')  P1OUT|=BIT0;     //�ߵ�ƽ���
//    if(BUF=='2')  P1OUT&=~BIT0;   //�͵�ƽϨ��
//    if(BUF=='3')  P4OUT|=BIT7;     //�ߵ�ƽ���
//    if(BUF=='4')  P4OUT&=~BIT7;   //�͵�ƽϨ��
//    break;
//  case 4:break;                             // Vector 4 - TXIFG
//  default: break;
//  }
//}
//// UCTXIFG=0x02��UCA1IFG&UCTXIFG����UCA1IFG��UCTXIFGλΪ1ʱ��˵��UCA1TXBUFΪ�գ�
////����whileѭ��ѭ������UCTXIFGλΪ0ʱUCA1TXBUF��Ϊ�գ�ͣ��ѭ����
//
