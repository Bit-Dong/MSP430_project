/*
 * pwm.h
 *
 *  Created on: 2022��5��1��
 *      Author: lenovo
 */

#ifndef HARDWARE_PWM_H_
#define HARDWARE_PWM_H_

void Timer0_Init(void);
void Timer1_Init(unsigned int i);//��ʼ��timer1 P2..0
void Timer2_Init(unsigned int i);//��ʼ��timer2 p2.4

#endif /* HARDWARE_PWM_H_ */
