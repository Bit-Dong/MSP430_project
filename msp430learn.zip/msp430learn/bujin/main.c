#include <msp430.h> 
#include <HARDWARE/led.h>
#include <HARDWARE/delay.h>
#include <HARDWARE/pwm.h>
#include <HARDWARE/pwm_bujin.h>

#define uchar unsigned char
#define uint unsigned int

int main( void )
{
  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD;

  Timer0_Init();
  BUJIN_Init();//��ʼ�������������
  LED_Init();
  Timer1_Init(1000);
  Timer2_Init(1000);
  while(1)
  {
      BUJIN_Pwm(2000,2000);
      TA1CCR1 = 10;     //ռ�ձ�: T[i] / 20000
      TA2CCR1 = 10;
  }
}




