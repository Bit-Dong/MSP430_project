#include <msp430.h> 
#include <HARDWARE/oled.h>
#include <HARDWARE/delay.h>
#include <HARDWARE/led.h>
/**
 * main.c
 */
int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	unsigned char i=0;

	OLED_Init();
	LED_Init();
	while(1)
	{
	    P1OUT |= BIT0;
	    OLED_ShowString(0,0,"Oledshow",16,1);
	    OLED_ShowString(0,16,"HaogeHaoge",16,1);
	    OLED_ShowNum(0,32,i,2,16,1);
	    OLED_Refresh();
	    delay_ms(1000);
	    P1OUT &= ~BIT0;
	    delay_ms(1000);
	    i++;
	    if(i==100) i=0;
	}
}
