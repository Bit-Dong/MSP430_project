/*
 * mpu6050.h
 *
 *  Created on: 2022楠烇拷7閺堬拷8閺冿拷
 *      Author: lenovo
 */

#ifndef MPU6050_H_
#define MPU6050_H_

#include <msp430.h>
#include <stdint.h>


//#define CPU_F ((double)16000000)
//#define delayus(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))  //瀹忓畾涔夊欢鏃跺嚱鏁�
//#define delayms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))

#define SCL1 P4OUT |=BIT1       //IIC鏁版嵁寮曡剼
#define SCL0 P4OUT &=~BIT1
#define SCLOUT P4DIR |= BIT1;


#define SDA1 P4OUT |=BIT2
#define SDA0 P4OUT &=~BIT2
#define SDAIN P4DIR &=~BIT2
#define SDAOUT P4DIR |=BIT2
#define SDADATA (P4IN & BIT2)

//********Mpu6050鐨勯浂鐐规牎鍑嗗��**************
#define MPU6050_ZERO_ACCELL 378
#define MPU6050_ZERO_GYRO 13

//*************瀹氫箟MPU6050鍐呴儴鍦板潃*******************
#define  SMPLRT_DIV    0x19  //闄�铻轰华閲囨牱鐜囷紝鍏稿瀷鍊硷細0x07(125Hz)
#define CONFIG      0x1A  //浣庨�氭护娉㈤鐜囷紝鍏稿瀷鍊硷細0x06(5Hz)
#define GYRO_CONFIG   0x1B  //闄�铻轰华鑷鍙婃祴閲忚寖鍥达紝鍏稿瀷鍊硷細0x18(涓嶈嚜妫�锛�2000deg/s)
#define ACCEL_CONFIG          0x1C  //鍔犻�熻鑷銆佹祴閲忚寖鍥村強楂橀�氭护娉㈤鐜囷紝鍏稿瀷鍊硷細0x01(涓嶈嚜妫�锛�2G锛�5Hz)
/***************鍔犻�熷害浼犳劅鍣ㄥ瘎瀛樺櫒******************/
#define ACCEL_XOUT_H          0x3B
#define ACCEL_XOUT_L          0x3C
#define ACCEL_XOUT      ACCEL_XOUT_H    // X杞磋鍙栧湴鍧�锛岄珮浣嶄负璧峰浣�
#define ACCEL_YOUT_H          0x3D
#define ACCEL_YOUT_L          0x3E
#define ACCEL_YOUT      ACCEL_YOUT_H    // Y杞磋鍙栧湴鍧�锛岄珮浣嶄负璧峰浣�
#define ACCEL_ZOUT_H          0x3F
#define ACCEL_ZOUT_L          0x40
#define ACCEL_ZOUT      ACCEL_ZOUT_H    // Z杞磋鍙栧湴鍧�锛岄珮浣嶄负璧峰浣�
/*****************娓╁害浼犳劅鍣ㄥ瘎瀛樺櫒****************/
#define TEMP_OUT_H    0x41
#define TEMP_OUT_L    0x42
#define TEMP_OUT          TEMP_OUT_H    // 娓╁害浼犳劅鍣ㄨ鍙栧湴鍧�锛岄珮浣嶄负璧峰浣�
/*****************闄�铻轰华瀵勫瓨鍣�********************/
#define GYRO_XOUT_H   0x43
#define GYRO_XOUT_L   0x44
#define GYRO_XOUT        GYRO_XOUT_H    // 闄�铻轰华X杞磋鍙栧湴鍧�锛岄珮浣嶄负璧峰浣�
#define GYRO_YOUT_H   0x45
#define GYRO_YOUT_L   0x46
#define GYRO_YOUT        GYRO_YOUT_H    // 闄�铻轰华Y杞磋鍙栧湴鍧�锛岄珮浣嶄负璧峰浣�
#define GYRO_ZOUT_H   0x47
#define GYRO_ZOUT_L   0x48
#define GYRO_ZOUT        GYRO_ZOUT_H    // 闄�铻轰华Z杞磋鍙栧湴鍧�锛岄珮浣嶄负璧峰浣�

#define PWR_MGMT_1    0x6B  //鐢垫簮绠＄悊锛屽吀鍨嬪�硷細0x00(姝ｅ父鍚敤)
#define WHO_AM_I          0x75  //IIC鍦板潃瀵勫瓨鍣�(榛樿鏁板��0x68锛屽彧璇�)
#define SlaveAddress          0xD0  //IIC鍐欏叆鏃剁殑鍦板潃瀛楄妭鏁版嵁锛�+1涓鸿鍙�

typedef signed char int8;
typedef unsigned char uchar;

unsigned char MPU_IIC_Read_Byte(unsigned char ack);
void InitMPU6050(void);
//float Mpu6050AccelAngle(int8 dir);
float Mpu6050AccelAngle(int8 dir);
float Mpu6050GyroAngle(int8 dir);



extern float Angle, Angle_dot;


#endif /* MPU6050_H_ */
