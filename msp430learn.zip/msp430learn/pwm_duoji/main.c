#include <msp430.h>
#include <HARDWARE/led.h>
#include <HARDWARE/delay.h>
#include <HARDWARE/pwm.h>

#define uchar unsigned char
#define uint unsigned int

int main( void )
{
  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD;

  Timer0_Init();
  Timer1_Init();
  Timer2_Init();
  LED_Init();

  while(1)
  {
//      TA1CCR1 = 1500;     //ռ�ձ�: T[i] / 20000
//      delay_ms(1000);
//      TA1CCR1 = 2000;
//      delay_ms(1000);

      TA0CCR1 = 800;     //ռ�ձ�: T[i] / 20000
      TA0CCR2 = 0;
      delay_ms(1000);
      delay_ms(1000);
      delay_ms(1000);
      delay_ms(1000);
      TA0CCR1 = 0;     //ռ�ձ�: T[i] / 20000
      TA0CCR2 = 800;
      delay_ms(1000);
      delay_ms(1000);
      delay_ms(1000);
      delay_ms(1000);

//        TA2CCR1 = 1500;     //ռ�ձ�: T[i] / 20000
//        delay_ms(1000);
//        TA2CCR1 = 2000;
//        delay_ms(1000);
  }
}
