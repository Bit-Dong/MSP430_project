/*
 * usart0.c
 *
 *  Created on: 2022��7��2��
 *      Author: lenovo
 */
#include "usart0.h"
#include "delay.h"

void uart0_Init(void)
{
    WDTCTL = WDTPW + WDTHOLD;  //Stop WDT
    P3SEL = BIT3+BIT4;
    // P3.3,P3.4 = USCI_A10 TXDRXD
    UCA0CTL1 = UCSWRST;
    UCA0CTL1 = UCSSEL_2;  //SMCLK
    UCA0BR0 = 9;
    UCA0BR1 = 0;  //1MHz 115200
    UCA0MCTL = UCBRS_1 + UCBRF_0;
    UCA0CTL1 &= ~UCSWRST;
    UCA0IE = UCRXIE;
    __bis_SR_register(LPM0_bits + GIE);
    __no_operation();  //For debugger

}





void send0_buf(unsigned char *ptr)    //�����ַ���
{
    while(*ptr != '\0')
    {
        while(!(UCA0IFG & UCTXIFG));
        UCA0TXBUF = *ptr;
        ptr++;
        delay_ms(10);
    }
}
