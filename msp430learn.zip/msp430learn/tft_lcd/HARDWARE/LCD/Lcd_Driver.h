#include "type.h"
#include "HARDWARE/delay.h"
#define CPU_F ((double)1000000)
//#define delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
//#define delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))

#define RED  	0xf800
#define GREEN	0x07e0
#define BLUE 	0x001f
#define WHITE	0xffff
#define BLACK	0x0000
#define YELLOW  0xFFE0
#define GRAY0   0xEF7D   	    //��ɫ0 3165 00110 001011 00101
#define GRAY1   0x8410      	//��ɫ1      00000 000000 00000
#define GRAY2   0x4208      	//��ɫ2  1111111111011111


#define LCD_SDA      P6DIR |= BIT0          //SDA
#define LCD_RS       P6DIR |= BIT1          //DC
#define LCD_CS       P6DIR |= BIT2          //CS
#define LCD_RST      P6DIR |= BIT3          //RES
#define LCD_SCL      P6DIR |= BIT4          //SCL
#define LCD_LED      P6DIR |= BIT5          //BL


//Һ�����ƿ���1�������궨��
#define	LCD_CS_SET  	 P6OUT |= BIT2
#define	LCD_RS_SET  	 P6OUT |= BIT1
#define	LCD_SDA_SET  	 P6OUT |= BIT0
#define	LCD_SCL_SET  	 P6OUT |= BIT4
#define	LCD_RST_SET  	 P6OUT |= BIT3
#define	LCD_LED_SET  	 P6OUT |= BIT5

//Һ�����ƿ���0�������궨��
#define	LCD_CS_CLR  	 P6OUT &=~ BIT2
#define	LCD_RS_CLR  	 P6OUT &=~ BIT1
#define	LCD_SDA_CLR  	 P6OUT &=~ BIT0
#define	LCD_SCL_CLR  	 P6OUT &=~ BIT4
#define	LCD_RST_CLR  	 P6OUT &=~ BIT3
#define	LCD_LED_CLR  	 P6OUT &=~ BIT5



void LCD_GPIO_Init(void);
void Lcd_WriteIndex(u8 Index);
void Lcd_WriteData(u8 Data);
void Lcd_WriteReg(u8 Index,u8 Data);
u16 Lcd_ReadReg(u8 LCD_Reg);
void Lcd_Reset(void);
void Lcd_Init(void);
void Lcd_Clear(u16 Color);
void Lcd_SetXY(u16 x,u16 y);
void Gui_DrawPoint(u16 x,u16 y,u16 Data);
unsigned int Lcd_ReadPoint(u16 x,u16 y);
void Lcd_SetRegion(u16 x_start,u16 y_start,u16 x_end,u16 y_end);
void LCD_WriteData_16Bit(u16 Data);

