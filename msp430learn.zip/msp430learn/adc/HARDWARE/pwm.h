/*
 * pwm.h
 *
 *  Created on: 2022��5��1��
 *      Author: lenovo
 */

#ifndef HARDWARE_PWM_H_
#define HARDWARE_PWM_H_

void Timer0_Init(void);
void Timer1_Init(void);
void Timer2_Init(void);

#endif /* HARDWARE_PWM_H_ */
