#include <msp430.h>
#include <HARDWARE/pwm.h>
/*
 ��ʱ��A0�����Ŷ���
P1.1/TA0.0//Ϊ����
P1.2/TA0.1
P1.3/TA0.2
P1.4/TA0.3
P1.5/TA0.4
 */
void Timer0_Init(void)
{
    P1DIR |= BIT2;                       // P2.0 and P2.1 output
    P1SEL |= BIT2;                       // P2.0 and P2.1 options select
    P1DIR |= BIT3;                       // P2.0 and P2.1 output
    P1SEL |= BIT3;                       // P2.0 and P2.1 options select
    TA0CCR0 = 20000;                          // PWM Period
    TA0CCTL1 = OUTMOD_7;
    TA0CCTL2 = OUTMOD_7;
    //TA0CCR0 = ����;                          //ռ�ձ�: T[i] / 20000// CCR1 reset/set
    TA0CTL = TASSEL_2 + MC_1 + TACLR;         // MCLK, up mode, clear TAR


}

/*
 ��ʱ��A1�����Ŷ���
P1.7/TA1.0
P2.0/TA1.1
P2.1/TA1.2
 */
void Timer1_Init(void)//��ʼ��timer1 P2..0
{
  P2DIR |= BIT0;                       // P2.0 and P2.1 output
  P2SEL |= BIT0;                       // P2.0 and P2.1 options select
  TA1CCR0 = 20000;                          // PWM Period
  TA1CCTL1 = OUTMOD_7;
  //TA1CCR1 = 1500;     //ռ�ձ�: T[i] / 20000// CCR1 reset/set
  TA1CTL = TASSEL_2 + MC_1 + TACLR;         // MCLK, up mode, clear TAR

}
/*
 ��ʱ��A2�����Ŷ���
P2.3/TA2.0
P2.4/TA2.1
P2.5/TA2.2
 */
void Timer2_Init(void)
{
    P2DIR |= BIT4;                       // P2.0 and P2.1 output
    P2SEL |= BIT4;                       // P2.0 and P2.1 options select
    TA2CCR0 = 20000;                          // PWM Period
    TA2CCTL1 = OUTMOD_7;
    //TA1CCR1 = 1500;     //ռ�ձ�: T[i] / 20000// CCR1 reset/set
    TA2CTL = TASSEL_2 + MC_1 + TACLR;         // MCLK, up mode, clear TAR
}
/*
 ��ʱ��B0�����Ŷ���
P3.6/TB0.0
P5.6/TB0.1
P5.7/TB0.2
P7.4/TB0.3
P7.5/TB0.4
P7.6/TB0.5
P7.7/TB0.6
 */
