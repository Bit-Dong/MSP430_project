/*
 * usart0.c
 *
 *  Created on: 2022��7��2��
 *      Author: lenovo
 */
#include "usart0.h"
#include "delay.h"

void uart0_Init(void)
{
    //���ڳ�ʼ��
     P3SEL    |=  BIT3+BIT4;                       // P5.6,7 = USCI_A1 TXD/RXD
     UCA0CTL1 |=  UCSWRST;                      // **Put state machine in reset**
     UCA0CTL1 |=  UCSSEL_1;                     // ACLK
     UCA0BR0   =  0x03;                         // 32768Hz 9600 ������Ϊ9600
     UCA0BR1   =  0x00;                             // 32768Hz 9600
     UCA0MCTL |=  UCBRS_3 + UCBRF_0;           // Modulation UCBRSx=1, UCBRFx=0  ok
     //UCA0MCTL = UCBRS_0 + UCBRF_13 + UCOS16;
     UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
     UCA0IE |=  UCRXIE;                       // Enable USCI_A1 RX interrupt ʹ���ж�



//     //���ڳ�ʼ��
//      P3SEL    |=  BIT3+BIT4;                       // P5.6,7 = USCI_A1 TXD/RXD
//      UCA0CTL1 |=  UCSWRST;                      // **Put state machine in reset**
//      UCA0CTL1 = UCSSEL_2;  //SMCLK
//      UCA0BR0 = 9;
//      UCA0BR1 = 0;  //1MHz 115200
//      UCA0MCTL = UCBRS_1 + UCBRF_0;
//      //UCA0MCTL = UCBRS_0 + UCBRF_13 + UCOS16;
//      UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
//      UCA0IE |=  UCRXIE;                       // Enable USCI_A1 RX interrupt ʹ���ж�




}

void send_buf(unsigned char *ptr)    //�����ַ���
{
    while(*ptr != '\0')
    {
        while(!(UCA0IFG & UCTXIFG));
        UCA0TXBUF = *ptr;
        ptr++;
        delay_us(500);
    }
}




