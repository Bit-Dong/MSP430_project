

#ifndef HARDWARE_PWM_H_
#define HARDWARE_PWM_H_

//#include "msp430f5529_system.h"
//#include "msp430f5529_clock.h"
//#include "msp430f5529_watchdog.h"
//#include "msp430f5529_gpio.h"
//#include "msp430f5529_timer.h"
//#include "msp430f5529_adc.h"
//#include "msp430f5529_uart.h"
//#include "msp430f5529_i2c.h"
//#include "msp430f5529_spi.h"
//#include "msp430f5529_flash.h"
//#include "msp430f5529_rtc.h"
//#include "msp430f5529_dma.h"
//#include "msp430f5529_compater.h"
//#include "msp430f5529_lpm.h"
//#include "msp430f5529_nmi.h"
//#include "msp430f5529_remap.h"
//#include "msp430f5529_it.h"
//#include "msp430f5529_vectors.h"

//void Timer0_Init(void);
//void Timer1_Init(void);
//void Timer2_Init(void);

void SetPwm_Init(int pwm,int psc,int arr);

#endif /* HARDWARE_PWM_H_ */
