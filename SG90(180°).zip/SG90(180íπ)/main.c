#include <msp430.h>
#include <HARDWARE/led.h>
#include <HARDWARE/delay.h>
#include <HARDWARE/pwm.h>

#define uchar unsigned char
#define uint unsigned int

void SG90_angle(int a);
void SG90_Cal(void);

int main( void )
{
  WDTCTL = WDTPW + WDTHOLD;

  while(1)
  {
      SG90_Cal();
  }
}


/*
 *                 20msΪ��
 *
 *                 180����
            0.5ms ------------ 0�ȣ�
            1.0ms ------------ 45�ȣ�
            1.5ms ------------ 90�ȣ�
            2.0ms ------------ 135�ȣ�
            2.5ms ------------ 180�ȣ�
 *
 *
 *                  360����
 *          0.5ms----------------�������ת�٣�
            1.5ms----------------�ٶ�Ϊ0��
            2.5ms----------------�������ת�٣�
 * */
/*          a=0   ---- 0.5ms
 *          a=90  ---- 1.5ms
 *          a=180 ---- 2.5ms
 * */
void SG90_angle(int a)
{
    int pwm=50+200/180*a;
    SetPwm_Init(24,2000,pwm);
}

void SG90_Cal(void)
{
    int i=0,j=0;
    for(i=0;i<=180;i++)
    {
        delay_ms(10);
        SG90_angle(i);
    }
    for(j=180;j>=0;j--)
    {
        delay_ms(10);
        SG90_angle(j);
    }
}
